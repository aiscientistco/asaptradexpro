ASAP Trade X Pro Working

Open index.html in Chrome.

Fixes in this version:
- Buy/Sell creates visible chart markers.
- Open spot position panel shows selected coin position.
- Open/recent orders panel shows filled order like real exchange.
- Toast confirmation after every trade.
- Futures open position visible with live P&L.
- Chart updates live using Binance public data with demo fallback.
- Wallet/portfolio/history update instantly.
